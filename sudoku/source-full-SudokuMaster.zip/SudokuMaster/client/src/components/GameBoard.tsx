import React, { useState, useEffect, useCallback } from 'react';
import { Settings, RefreshCw, AlertTriangle, Lightbulb } from 'lucide-react';
import SudokuGrid from './SudokuGrid';
import NumberPad from './NumberPad';
import GameInfo from './GameInfo';
import SettingsPanel from './SettingsPanel';
import { useSudoku } from '@/hooks/useSudoku';
import { useTimer } from '@/hooks/useTimer';
import { useGameSettings } from '@/hooks/useGameSettings';
import { formatTime } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";

const GameBoard: React.FC = () => {
  const { settings, updateGridSize, updateDifficulty, updateHighlightSettings } = useGameSettings();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [showCompletionDialog, setShowCompletionDialog] = useState(false);
  const [showIncorrectDialog, setShowIncorrectDialog] = useState(false);
  const [showHintDialog, setShowHintDialog] = useState(false);
  const [currentHint, setCurrentHint] = useState<{row: number, col: number, value: number, reason: string} | null>(null);
  const { toast } = useToast();
  
  const {
    grid,
    selectedCell,
    isComplete,
    isPaused,
    isFilled,
    isIncorrect,
    selectCell,
    inputNumber,
    eraseCell,
    newGame,
    updateElapsedTime,
    getHint,
    applyHint
  } = useSudoku(settings.gridSize, settings.difficulty);
  
  const {
    elapsedTime,
    formattedTime,
    start,
    pause,
    reset
  } = useTimer({ autoStart: true });
  
  // Handle keyboard navigation
  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    if (isComplete || isPaused || isSettingsOpen || showCompletionDialog || showIncorrectDialog) {
      return;
    }
    
    // Handle arrow key navigation
    if (event.key === 'ArrowUp' || event.key === 'ArrowDown' || 
        event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      
      // If no cell is selected, select the first non-given cell
      if (!selectedCell) {
        for (let r = 0; r < grid.length; r++) {
          for (let c = 0; c < grid[r].length; c++) {
            if (!grid[r][c].isGiven) {
              selectCell(r, c);
              return;
            }
          }
        }
        return;
      }
      
      const { row, col } = selectedCell;
      let newRow = row;
      let newCol = col;
      
      // Calculate new position
      if (event.key === 'ArrowUp') {
        newRow = (row - 1 + settings.gridSize) % settings.gridSize;
      } else if (event.key === 'ArrowDown') {
        newRow = (row + 1) % settings.gridSize;
      } else if (event.key === 'ArrowLeft') {
        newCol = (col - 1 + settings.gridSize) % settings.gridSize;
      } else if (event.key === 'ArrowRight') {
        newCol = (col + 1) % settings.gridSize;
      }
      
      // Find the next selectable cell in the direction
      let attempts = 0;
      const maxAttempts = settings.gridSize * settings.gridSize;
      
      while (grid[newRow][newCol].isGiven && attempts < maxAttempts) {
        attempts++;
        if (event.key === 'ArrowUp') {
          newRow = (newRow - 1 + settings.gridSize) % settings.gridSize;
        } else if (event.key === 'ArrowDown') {
          newRow = (newRow + 1) % settings.gridSize;
        } else if (event.key === 'ArrowLeft') {
          newCol = (newCol - 1 + settings.gridSize) % settings.gridSize;
        } else if (event.key === 'ArrowRight') {
          newCol = (newCol + 1) % settings.gridSize;
        }
      }
      
      // If we found a non-given cell, select it
      if (!grid[newRow][newCol].isGiven) {
        selectCell(newRow, newCol);
      }
    }
    
    // Handle number keys (1-9)
    if (/^[1-9]$/.test(event.key) && selectedCell) {
      const number = parseInt(event.key);
      inputNumber(number);
    }
    
    // Handle delete/backspace
    if ((event.key === 'Delete' || event.key === 'Backspace') && selectedCell) {
      eraseCell();
    }
    
  }, [grid, selectedCell, selectCell, inputNumber, eraseCell, isComplete, isPaused, 
      isSettingsOpen, showCompletionDialog, showIncorrectDialog, settings.gridSize]);
  
  // Add keyboard event listener
  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleKeyDown]);
  
  // Update game elapsed time whenever timer changes
  useEffect(() => {
    updateElapsedTime(elapsedTime);
  }, [elapsedTime, updateElapsedTime]);
  
  // Show completion dialog when game is completed
  useEffect(() => {
    if (isComplete) {
      pause();
      setShowCompletionDialog(true);
      toast({
        title: "🎉 Well done!",
        description: `You solved the puzzle in ${formatTime(elapsedTime, true)}!`,
        variant: "default"
      });
    }
  }, [isComplete, pause, elapsedTime, toast]);
  
  // Show incorrect solution dialog when appropriate
  useEffect(() => {
    if (isIncorrect) {
      pause();
      setShowIncorrectDialog(true);
    }
  }, [isIncorrect, pause]);
  
  // Handle new game from settings
  const handleApplySettings = () => {
    setIsSettingsOpen(false);
    newGame(settings.gridSize, settings.difficulty);
    reset();
    start();
  };
  
  // Handle hint request
  const handleRequestHint = () => {
    const hint = getHint();
    if (hint) {
      setCurrentHint(hint);
      setShowHintDialog(true);
    } else {
      toast({
        title: "No hints available",
        description: "The puzzle is either solved or there are no logical next moves",
        variant: "destructive"
      });
    }
  };
  
  // Handle hint application - actually input the value
  const handleApplyHint = () => {
    if (currentHint) {
      // The hint cell should already be selected by the getHint function
      inputNumber(currentHint.value);
      setShowHintDialog(false);
      
      toast({
        title: "Hint applied",
        description: `Placed ${currentHint.value} at row ${currentHint.row + 1}, column ${currentHint.col + 1}`,
        variant: "default"
      });
    }
  };
  
  // Handle number input
  const handleNumberInput = (number: number) => {
    inputNumber(number);
  };
  
  // Handle new game button
  const handleNewGame = () => {
    newGame(settings.gridSize, settings.difficulty);
    reset();
    start();
    setShowIncorrectDialog(false);
  };
  
  // Determine grid container class based on game state
  const gridContainerClass = isComplete 
    ? "bg-green-50 border-2 border-green-500 rounded-xl p-2 transition-all duration-500" 
    : isIncorrect 
      ? "bg-red-50 border-2 border-red-500 rounded-xl p-2 transition-all duration-500" 
      : "bg-white border border-gray-200 rounded-xl p-2 shadow-md";
  
  return (
    <>
      <header className="flex justify-between items-center mb-3 sm:mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Sudoku</h1>
        
        <div className="flex space-x-2">
          {/* New Game Button */}
          <Button
            variant="outline"
            className="bg-white shadow-sm hover:bg-indigo-50 transition-colors flex items-center"
            onClick={handleNewGame}
            aria-label="New Game"
          >
            <RefreshCw className="h-4 w-4 mr-1" />
            <span>New</span>
          </Button>
          
          {/* Settings Button */}
          <Button
            variant="ghost"
            size="icon"
            className="p-2 rounded-full bg-white shadow-sm hover:bg-gray-100 transition-colors"
            onClick={() => setIsSettingsOpen(true)}
            aria-label="Settings"
          >
            <Settings className="h-6 w-6" />
          </Button>
        </div>
      </header>
      
      <GameInfo
        difficulty={settings.difficulty}
        elapsedTime={elapsedTime}
      />
      
      <SudokuGrid
        grid={grid}
        selectedCell={selectedCell}
        onCellClick={selectCell}
        size={settings.gridSize}
        highlightSettings={settings.highlightSettings}
        disabled={isComplete || isPaused || isIncorrect}
        containerClassName={gridContainerClass}
      />
      
      <NumberPad
        onNumberSelect={handleNumberInput}
        onErase={eraseCell}
        size={settings.gridSize}
        disabled={!selectedCell || isComplete || isPaused || isIncorrect}
      />
      
      <SettingsPanel
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateGridSize={updateGridSize}
        onUpdateDifficulty={updateDifficulty}
        onUpdateHighlightSettings={updateHighlightSettings}
        onApply={handleApplySettings}
        onRequestHint={handleRequestHint}
      />
      
      {/* Hint dialog */}
      <AlertDialog open={showHintDialog} onOpenChange={setShowHintDialog}>
        <AlertDialogContent className="bg-amber-50 border border-amber-200">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-amber-700 flex items-center">
              <Lightbulb className="h-5 w-5 mr-2" />
              Hint
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-700">
              {currentHint && (
                <>
                  <p className="font-medium mb-2">
                    You should place {currentHint.value} in row {currentHint.row + 1}, column {currentHint.col + 1}.
                  </p>
                  <p>{currentHint.reason}</p>
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowHintDialog(false)} className="bg-gray-600 hover:bg-gray-700">
              I'll solve it myself
            </AlertDialogAction>
            <AlertDialogAction onClick={handleApplyHint} className="bg-amber-600 hover:bg-amber-700">
              Apply this hint
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Success dialog */}
      <AlertDialog open={showCompletionDialog} onOpenChange={setShowCompletionDialog}>
        <AlertDialogContent className="bg-green-50 border border-green-200">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-green-700">Congratulations! 🎉</AlertDialogTitle>
            <AlertDialogDescription>
              You've completed the Sudoku puzzle in {formatTime(elapsedTime, true)}!
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={handleNewGame} className="bg-green-600 hover:bg-green-700">
              Start New Game
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Incorrect solution dialog */}
      <AlertDialog open={showIncorrectDialog} onOpenChange={setShowIncorrectDialog}>
        <AlertDialogContent className="bg-red-50 border border-red-200">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-red-700 flex items-center">
              <AlertTriangle className="h-5 w-5 mr-2" />
              Incorrect Solution
            </AlertDialogTitle>
            <AlertDialogDescription>
              Your solution contains errors. Check the grid and try again.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowIncorrectDialog(false)} className="bg-gray-600 hover:bg-gray-700">
              Keep Trying
            </AlertDialogAction>
            <AlertDialogAction onClick={handleNewGame} className="bg-red-600 hover:bg-red-700">
              New Game
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default GameBoard;
