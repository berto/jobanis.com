import React, { useMemo } from 'react';
import { cn } from '@/lib/utils';
import { SudokuGrid as SudokuGridType, SelectedCell, GridSize, HighlightSettings } from '@/types';
import { getHighlightedCells } from '@/lib/sudoku';

interface SudokuGridProps {
  grid: SudokuGridType;
  selectedCell: SelectedCell;
  onCellClick: (row: number, col: number) => void;
  size: GridSize;
  highlightSettings: HighlightSettings;
  disabled?: boolean;
  containerClassName?: string;
}

const SudokuGrid: React.FC<SudokuGridProps> = ({
  grid,
  selectedCell,
  onCellClick,
  size,
  highlightSettings,
  disabled = false,
  containerClassName
}) => {
  // Calculate which cells should be highlighted
  const highlightedCells = useMemo(() => {
    return getHighlightedCells(selectedCell, grid, size, highlightSettings);
  }, [selectedCell, grid, size, highlightSettings]);

  // Function to determine if a cell should be highlighted and with what intensity
  const getCellHighlight = (row: number, col: number) => {
    if (selectedCell && selectedCell.row === row && selectedCell.col === col) {
      return 'bg-indigo-100'; // Selected cell
    }
    
    const highlightTypes = highlightedCells
      .filter(cell => cell.row === row && cell.col === col)
      .map(cell => cell.type);
    
    if (highlightTypes.length > 0) {
      if (highlightTypes.includes('same-number')) {
        return 'bg-indigo-50'; // Higher priority
      }
      return 'bg-indigo-50/70'; // Row, column, or box
    }
    
    return '';
  };

  // Function to determine border styles for cells
  const getBorderStyles = (row: number, col: number) => {
    const boxSize = size === 4 ? 2 : 3;
    const classes = [];
    
    // All cells have these borders
    classes.push('border-t border-l');
    
    // Right borders
    if (col === size - 1) {
      classes.push('border-r');
    }
    
    // Bottom borders
    if (row === size - 1) {
      classes.push('border-b');
    }
    
    // Thick right border for cells at the end of a box
    if ((col + 1) % boxSize === 0 && col !== size - 1) {
      classes.push('border-r-2 border-r-gray-800');
    } else if (col === size - 1) {
      classes.push('border-r-gray-400');
    } else {
      classes.push('border-r-gray-200');
    }
    
    // Thick bottom border for cells at the bottom of a box
    if ((row + 1) % boxSize === 0 && row !== size - 1) {
      classes.push('border-b-2 border-b-gray-800');
    } else if (row === size - 1) {
      classes.push('border-b-gray-400');
    } else {
      classes.push('border-b-gray-200');
    }
    
    // Border colors for top and left
    classes.push('border-l-gray-200 border-t-gray-200');
    
    return classes.join(' ');
  };

  return (
    <div className={cn("relative mb-4 sm:mb-6", containerClassName)}>
      <div 
        className={cn(
          "grid gap-0 relative overflow-hidden max-h-[65vh] md:max-h-none", 
          size === 4 ? "grid-cols-4" : "grid-cols-9"
        )}
        style={{
          borderRadius: '0.5rem',
          border: '2px solid #9CA3AF',
        }}
      >
        {grid.map((row, rowIndex) => 
          row.map((cell, colIndex) => (
            <div
              key={`${rowIndex}-${colIndex}`}
              className={cn(
                "sudoku-cell flex items-center justify-center w-full select-none aspect-square",
                getBorderStyles(rowIndex, colIndex),
                getCellHighlight(rowIndex, colIndex),
                cell.isGiven ? 'cursor-default' : 'cursor-pointer',
                disabled && 'opacity-60'
              )}
              onClick={() => !disabled && onCellClick(rowIndex, colIndex)}
              aria-label={`Cell at row ${rowIndex + 1}, column ${colIndex + 1}`}
              data-row={rowIndex}
              data-col={colIndex}
              data-given={cell.isGiven}
              data-selected={selectedCell?.row === rowIndex && selectedCell?.col === colIndex}
              aria-selected={selectedCell?.row === rowIndex && selectedCell?.col === colIndex}
            >
              <span 
                className={cn(
                  "text-base sm:text-lg font-medium",
                  cell.isGiven ? 'text-gray-800' : 'text-indigo-600'
                )}
              >
                {cell.value || ''}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default SudokuGrid;
