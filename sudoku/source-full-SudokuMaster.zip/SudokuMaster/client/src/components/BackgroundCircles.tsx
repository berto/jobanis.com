import React, { useEffect, useRef } from 'react';
import { generateRandomPastelColor } from '@/lib/utils';

type Circle = {
  x: number;
  y: number;
  size: number;
  color: string;
};

const BackgroundCircles: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!containerRef.current) return;
    
    const generateCircles = () => {
      const container = containerRef.current;
      if (!container) return;
      
      // Clear existing circles
      container.innerHTML = '';
      
      // Define pastel colors
      const colors = [
        '#FDD2E5', // pink
        '#D9F2FD', // light blue
        '#DAF8E6', // mint
        '#FDE2C9', // peach
        '#F0E2FD', // lavender
        '#FDF9C9'  // light yellow
      ];
      
      // Get viewport dimensions plus some extra to ensure coverage
      const viewportWidth = window.innerWidth + 200;
      const viewportHeight = window.innerHeight + 200;
      
      // Generate more circles for better coverage
      const numCircles = Math.floor(Math.random() * 16) + 25; // 25-40 circles
      
      const circles: Circle[] = [];
      
      // Distribute circles across the entire viewport
      for (let i = 0; i < numCircles; i++) {
        const size = Math.floor(Math.random() * 301) + 150; // 150-450px
        const x = Math.random() * viewportWidth - 100; // Some can be off-screen
        const y = Math.random() * viewportHeight - 100; // Some can be off-screen
        const color = colors[Math.floor(Math.random() * colors.length)];
        
        circles.push({ x, y, size, color });
      }
      
      // Create and append circle elements
      circles.forEach(circle => {
        const element = document.createElement('div');
        element.style.position = 'absolute';
        element.style.width = `${circle.size}px`;
        element.style.height = `${circle.size}px`;
        element.style.borderRadius = '50%';
        element.style.backgroundColor = circle.color;
        element.style.opacity = '0.7';
        element.style.left = `${circle.x}px`;
        element.style.top = `${circle.y}px`;
        element.style.transform = 'translateX(-50%) translateY(-50%)';
        element.style.filter = 'blur(20px)';
        element.style.pointerEvents = 'none'; // Make sure clicks go through
        
        container.appendChild(element);
      });
    };
    
    // Generate circles initially
    generateCircles();
    
    // Regenerate circles when window is resized
    const handleResize = () => {
      generateCircles();
    };
    
    // Listen for scroll events to ensure circles are visible while scrolling
    const handleScroll = () => {
      if (containerRef.current) {
        containerRef.current.style.transform = `translateY(${window.scrollY * 0.5}px)`;
      }
    };
    
    window.addEventListener('resize', handleResize);
    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  
  return (
    <div
      ref={containerRef}
      className="fixed inset-0 overflow-hidden z-0"
      aria-hidden="true"
      style={{ 
        minHeight: '200vh', // Ensure it's at least twice the viewport height
        height: '100%',  // Fill the entire height
        width: '100vw',
        top: 0,
        left: 0,
        bottom: 0,
        right: 0
      }}
    />
  );
};

export default BackgroundCircles;
