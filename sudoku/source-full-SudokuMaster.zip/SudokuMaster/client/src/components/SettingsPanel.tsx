import React from 'react';
import { 
  Dialog, 
  DialogContent,
  DialogTitle,
  DialogHeader,
  DialogClose
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { GridSize, Difficulty, GameSettings } from '@/types';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateGridSize: (size: GridSize) => void;
  onUpdateDifficulty: (difficulty: Difficulty) => void;
  onUpdateHighlightSettings: (settings: Partial<{
    highlightRowColumn: boolean;
    highlightBox: boolean;
    highlightSameNumbers: boolean;
  }>) => void;
  onApply: () => void;
  onRequestHint?: () => void;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateGridSize,
  onUpdateDifficulty,
  onUpdateHighlightSettings,
  onApply,
  onRequestHint
}) => {
  const handleHighlightChange = (setting: keyof typeof settings.highlightSettings, value: boolean) => {
    onUpdateHighlightSettings({ [setting]: value });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white rounded-xl p-6 max-w-sm w-full mx-4">
        <DialogHeader className="mb-4">
          <DialogTitle className="text-xl font-bold">Settings</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-1">Grid Size</Label>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                className={cn(
                  settings.gridSize === 4 
                    ? "border-indigo-500 bg-indigo-50 text-indigo-700 font-medium" 
                    : "border-gray-300"
                )}
                onClick={() => onUpdateGridSize(4)}
              >
                4×4
              </Button>
              <Button
                variant="outline"
                className={cn(
                  settings.gridSize === 9 
                    ? "border-indigo-500 bg-indigo-50 text-indigo-700 font-medium" 
                    : "border-gray-300"
                )}
                onClick={() => onUpdateGridSize(9)}
              >
                9×9
              </Button>
            </div>
          </div>
          
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-1">Difficulty</Label>
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant="outline"
                className={cn(
                  settings.difficulty === 'easy' 
                    ? "border-indigo-500 bg-indigo-50 text-indigo-700 font-medium" 
                    : "border-gray-300"
                )}
                onClick={() => onUpdateDifficulty('easy')}
              >
                Easy
              </Button>
              <Button
                variant="outline"
                className={cn(
                  settings.difficulty === 'medium' 
                    ? "border-indigo-500 bg-indigo-50 text-indigo-700 font-medium" 
                    : "border-gray-300"
                )}
                onClick={() => onUpdateDifficulty('medium')}
              >
                Medium
              </Button>
              <Button
                variant="outline"
                className={cn(
                  settings.difficulty === 'hard' 
                    ? "border-indigo-500 bg-indigo-50 text-indigo-700 font-medium" 
                    : "border-gray-300"
                )}
                onClick={() => onUpdateDifficulty('hard')}
              >
                Hard
              </Button>
            </div>
          </div>
          
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-1">Highlight Settings</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="highlight-row-column"
                  checked={settings.highlightSettings.highlightRowColumn}
                  onCheckedChange={(checked) => 
                    handleHighlightChange('highlightRowColumn', checked === true)
                  }
                />
                <Label htmlFor="highlight-row-column" className="text-sm">
                  Highlight row & column
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="highlight-box"
                  checked={settings.highlightSettings.highlightBox}
                  onCheckedChange={(checked) => 
                    handleHighlightChange('highlightBox', checked === true)
                  }
                />
                <Label htmlFor="highlight-box" className="text-sm">
                  Highlight box
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="highlight-same-numbers"
                  checked={settings.highlightSettings.highlightSameNumbers}
                  onCheckedChange={(checked) => 
                    handleHighlightChange('highlightSameNumbers', checked === true)
                  }
                />
                <Label htmlFor="highlight-same-numbers" className="text-sm">
                  Highlight same numbers
                </Label>
              </div>
            </div>
          </div>
        </div>
        
        {onRequestHint && (
          <div className="mt-4">
            <Label className="block text-sm font-medium text-gray-700 mb-1">Game Help</Label>
            <Button
              variant="outline"
              className="w-full border-amber-500 bg-amber-50 text-amber-700 hover:bg-amber-100"
              onClick={onRequestHint}
            >
              Show me a hint with explanation
            </Button>
            <p className="text-xs text-gray-500 mt-1">
              Hints will show you the next logical move and explain why it's valid.
            </p>
          </div>
        )}
        
        <div className="mt-6 flex justify-end space-x-2">
          <Button
            variant="outline"
            className="px-4 py-2 text-gray-600 border-gray-300 rounded-lg shadow-sm hover:bg-gray-100 transition-colors"
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button
            className="px-4 py-2 bg-indigo-500 text-white rounded-lg shadow-sm hover:bg-indigo-600 active:bg-indigo-700 transition-colors"
            onClick={onApply}
          >
            Apply
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SettingsPanel;
