import React from 'react';
import { cn } from '@/lib/utils';
import { Trash2 } from 'lucide-react';
import { GridSize } from '@/types';

interface NumberPadProps {
  onNumberSelect: (number: number) => void;
  onErase: () => void;
  size: GridSize;
  disabled?: boolean;
}

const NumberPad: React.FC<NumberPadProps> = ({
  onNumberSelect,
  onErase,
  size,
  disabled = false
}) => {
  // Generate numbers 1 to size (4 or 9)
  const numbers = Array.from({ length: size }, (_, i) => i + 1);
  
  return (
    <div className="mb-6 w-full">
      <div className="flex justify-center mb-4 w-full">
        <div className="grid grid-cols-10 gap-1 w-full max-w-md">
          {numbers.map(number => (
            <button 
              key={number}
              className="number-button h-10 flex items-center justify-center bg-white rounded-lg shadow-sm hover:bg-indigo-50 active:bg-indigo-100 transition-colors"
              onClick={() => onNumberSelect(number)}
              disabled={disabled}
              aria-label={`Input number ${number}`}
            >
              <span className="text-lg font-medium">{number}</span>
            </button>
          ))}
          
          {/* Erase button - in the number pad */}
          <button 
            className="h-10 flex items-center justify-center bg-white rounded-lg shadow-sm hover:bg-red-50 active:bg-red-100 transition-colors"
            onClick={onErase}
            disabled={disabled}
            aria-label="Erase"
          >
            <Trash2 className="h-5 w-5 text-red-500" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default NumberPad;
