import React, { useState } from 'react';
import { formatTime } from '@/lib/utils';
import { Difficulty } from '@/types';

interface GameInfoProps {
  difficulty: Difficulty;
  elapsedTime: number;
}

const GameInfo: React.FC<GameInfoProps> = ({ difficulty, elapsedTime }) => {
  // Format the difficulty for display (capitalize first letter)
  const displayDifficulty = difficulty.charAt(0).toUpperCase() + difficulty.slice(1);
  const [showSeconds, setShowSeconds] = useState(false);
  
  // Toggle between minute-only and minutes:seconds format
  const toggleTimeFormat = () => {
    setShowSeconds(prev => !prev);
  };
  
  return (
    <div className="flex justify-between items-center mb-4 text-sm">
      <div className="bg-white rounded-lg shadow-sm px-3 py-2">
        <span className="font-medium">Difficulty:</span>{' '}
        <span id="difficulty-display">{displayDifficulty}</span>
      </div>
      <div 
        className="bg-white rounded-lg shadow-sm px-3 py-2 cursor-pointer" 
        onClick={toggleTimeFormat}
        title="Click to toggle time format"
      >
        <span className="font-medium">Time:</span>{' '}
        <span id="timer">{formatTime(elapsedTime, showSeconds)}</span>
      </div>
    </div>
  );
};

export default GameInfo;
