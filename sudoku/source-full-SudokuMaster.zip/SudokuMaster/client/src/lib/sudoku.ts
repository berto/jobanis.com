import { SudokuGrid, SudokuCell, GridSize, Difficulty } from "../types";
import { getBoxBounds } from "./utils";

// Create empty grid of the given size
const createEmptyGrid = (size: GridSize): SudokuGrid => {
  return Array(size).fill(null).map(() => 
    Array(size).fill(null).map(() => ({
      value: null,
      isGiven: false,
      notes: []
    }))
  );
};

// Create a filled valid sudoku solution
const generateSolution = (size: GridSize): number[][] => {
  const grid: number[][] = Array(size).fill(null).map(() => Array(size).fill(0));
  
  // Helper function to check if a value is valid at a given position
  const isValid = (row: number, col: number, num: number): boolean => {
    // Check row
    for (let x = 0; x < size; x++) {
      if (grid[row][x] === num) return false;
    }
    
    // Check column
    for (let x = 0; x < size; x++) {
      if (grid[x][col] === num) return false;
    }
    
    // Check box
    const boxSize = size === 4 ? 2 : 3;
    const boxRow = Math.floor(row / boxSize) * boxSize;
    const boxCol = Math.floor(col / boxSize) * boxSize;
    
    for (let r = 0; r < boxSize; r++) {
      for (let c = 0; c < boxSize; c++) {
        if (grid[boxRow + r][boxCol + c] === num) return false;
      }
    }
    
    return true;
  };
  
  // Recursive function to fill the grid
  const fillGrid = (row: number, col: number): boolean => {
    if (row === size) return true;
    
    if (col === size) return fillGrid(row + 1, 0);
    
    if (grid[row][col] !== 0) return fillGrid(row, col + 1);
    
    // Shuffle the numbers 1-size
    const numbers = Array.from({length: size}, (_, i) => i + 1);
    for (let i = numbers.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [numbers[i], numbers[j]] = [numbers[j], numbers[i]];
    }
    
    for (const num of numbers) {
      if (isValid(row, col, num)) {
        grid[row][col] = num;
        
        if (fillGrid(row, col + 1)) return true;
        
        grid[row][col] = 0;
      }
    }
    
    return false;
  };
  
  fillGrid(0, 0);
  return grid;
};

// Create a puzzle by removing values from a solution
const createPuzzle = (solution: number[][], difficulty: Difficulty, size: GridSize): SudokuGrid => {
  // Clone the solution
  const gridValues = solution.map(row => [...row]);
  
  // Determine how many cells to remove based on difficulty and grid size
  let cellsToRemove: number;
  
  if (size === 4) {
    switch (difficulty) {
      case 'easy': cellsToRemove = 4; break; // Remove ~25% (much easier)
      case 'medium': cellsToRemove = 8; break; // Remove ~50%
      case 'hard': cellsToRemove = 10; break; // Remove ~62.5%
      default: cellsToRemove = 8;
    }
  } else { // 9x9
    switch (difficulty) {
      case 'easy': cellsToRemove = 30; break; // Remove ~37% (much easier)
      case 'medium': cellsToRemove = 50; break; // Remove ~62%
      case 'hard': cellsToRemove = 60; break; // Remove ~74%
      default: cellsToRemove = 50;
    }
  }
  
  // Create positions array
  const positions: [number, number][] = [];
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      positions.push([row, col]);
    }
  }
  
  // Shuffle positions
  for (let i = positions.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [positions[i], positions[j]] = [positions[j], positions[i]];
  }
  
  // Remove values from the grid
  for (let i = 0; i < cellsToRemove && i < positions.length; i++) {
    const [row, col] = positions[i];
    gridValues[row][col] = 0;
  }
  
  // Convert to SudokuGrid format
  return gridValues.map((row, rowIndex) =>
    row.map((value, colIndex) => ({
      value: value === 0 ? null : value,
      isGiven: value !== 0,
      notes: []
    }))
  );
};

// Generate a playable sudoku puzzle
export const generateSudoku = (size: GridSize, difficulty: Difficulty): { grid: SudokuGrid, solution: number[][] } => {
  const solution = generateSolution(size);
  const grid = createPuzzle(solution, difficulty, size);
  return { grid, solution };
};

// Check if a value is valid at a given position
export const isValidValue = (grid: SudokuGrid, row: number, col: number, value: number, size: GridSize): boolean => {
  // Check row
  for (let c = 0; c < size; c++) {
    if (c !== col && grid[row][c].value === value) return false;
  }
  
  // Check column
  for (let r = 0; r < size; r++) {
    if (r !== row && grid[r][col].value === value) return false;
  }
  
  // Check box
  const boxBounds = getBoxBounds(row, col, size);
  for (let r = boxBounds.startRow; r <= boxBounds.endRow; r++) {
    for (let c = boxBounds.startCol; c <= boxBounds.endCol; c++) {
      if (r !== row || c !== col) {
        if (grid[r][c].value === value) return false;
      }
    }
  }
  
  return true;
};

// Check if the sudoku grid is completely filled and valid
export const isSudokuComplete = (grid: SudokuGrid, size: GridSize): boolean => {
  // Check if all cells are filled
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (grid[row][col].value === null) return false;
      
      // Check if the value is valid
      if (!isValidValue(grid, row, col, grid[row][col].value as number, size)) {
        return false;
      }
    }
  }
  
  return true;
};

// Check if all cells are filled, regardless of correctness
export const isGridFilled = (grid: SudokuGrid): boolean => {
  for (let row = 0; row < grid.length; row++) {
    for (let col = 0; col < grid[row].length; col++) {
      if (grid[row][col].value === null) {
        return false;
      }
    }
  }
  return true;
};

// Return cells that should be highlighted based on selected cell
export const getHighlightedCells = (
  selectedCell: { row: number; col: number } | null,
  grid: SudokuGrid,
  size: GridSize,
  highlightSettings: { highlightRowColumn: boolean; highlightBox: boolean; highlightSameNumbers: boolean; }
): { row: number; col: number; type: 'row' | 'column' | 'box' | 'same-number' }[] => {
  if (!selectedCell) return [];
  
  const highlights: { row: number; col: number; type: 'row' | 'column' | 'box' | 'same-number' }[] = [];
  const { row, col } = selectedCell;
  
  // Highlight row
  if (highlightSettings.highlightRowColumn) {
    for (let c = 0; c < size; c++) {
      if (c !== col) {
        highlights.push({ row, col: c, type: 'row' });
      }
    }
  }
  
  // Highlight column
  if (highlightSettings.highlightRowColumn) {
    for (let r = 0; r < size; r++) {
      if (r !== row) {
        highlights.push({ row: r, col, type: 'column' });
      }
    }
  }
  
  // Highlight box
  if (highlightSettings.highlightBox) {
    const boxBounds = getBoxBounds(row, col, size);
    for (let r = boxBounds.startRow; r <= boxBounds.endRow; r++) {
      for (let c = boxBounds.startCol; c <= boxBounds.endCol; c++) {
        if (r !== row || c !== col) {
          highlights.push({ row: r, col: c, type: 'box' });
        }
      }
    }
  }
  
  // Highlight same numbers
  if (highlightSettings.highlightSameNumbers && grid[row][col].value !== null) {
    const value = grid[row][col].value;
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if ((r !== row || c !== col) && grid[r][c].value === value) {
          highlights.push({ row: r, col: c, type: 'same-number' });
        }
      }
    }
  }
  
  return highlights;
};

// Finds the next logical hint for the player
export const findHint = (
  grid: SudokuGrid, 
  solution: number[][], 
  size: GridSize
): { row: number; col: number; value: number; reason: string } | null => {
  // First, we'll check for cells with only one possible value
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      // Skip cells that already have values
      if (grid[row][col].value !== null || grid[row][col].isGiven) continue;
      
      // Find possible values for this cell
      const possibleValues = [];
      for (let value = 1; value <= size; value++) {
        if (isValidValue(grid, row, col, value, size)) {
          possibleValues.push(value);
        }
      }
      
      // If only one possibility, that's a good hint
      if (possibleValues.length === 1) {
        return {
          row,
          col,
          value: possibleValues[0],
          reason: `This cell can only contain ${possibleValues[0]} because all other numbers would create conflicts with existing values in the same row, column, or box.`
        };
      }
    }
  }
  
  // Next strategy: Look for rows, columns, or boxes where a number can only go in one place
  for (let value = 1; value <= size; value++) {
    // Check rows
    for (let row = 0; row < size; row++) {
      let possiblePositions = [];
      for (let col = 0; col < size; col++) {
        if (grid[row][col].value === null && !grid[row][col].isGiven && isValidValue(grid, row, col, value, size)) {
          possiblePositions.push({ row, col });
        }
      }
      if (possiblePositions.length === 1) {
        return {
          row: possiblePositions[0].row,
          col: possiblePositions[0].col,
          value,
          reason: `The number ${value} can only be placed in this cell in row ${possiblePositions[0].row + 1} because all other positions in this row would create conflicts.`
        };
      }
    }
    
    // Check columns
    for (let col = 0; col < size; col++) {
      let possiblePositions = [];
      for (let row = 0; row < size; row++) {
        if (grid[row][col].value === null && !grid[row][col].isGiven && isValidValue(grid, row, col, value, size)) {
          possiblePositions.push({ row, col });
        }
      }
      if (possiblePositions.length === 1) {
        return {
          row: possiblePositions[0].row,
          col: possiblePositions[0].col,
          value,
          reason: `The number ${value} can only be placed in this cell in column ${possiblePositions[0].col + 1} because all other positions in this column would create conflicts.`
        };
      }
    }
    
    // Check boxes
    const boxSize = size === 4 ? 2 : 3;
    for (let boxRow = 0; boxRow < size; boxRow += boxSize) {
      for (let boxCol = 0; boxCol < size; boxCol += boxSize) {
        let possiblePositions = [];
        for (let r = 0; r < boxSize; r++) {
          for (let c = 0; c < boxSize; c++) {
            const row = boxRow + r;
            const col = boxCol + c;
            if (grid[row][col].value === null && !grid[row][col].isGiven && isValidValue(grid, row, col, value, size)) {
              possiblePositions.push({ row, col });
            }
          }
        }
        if (possiblePositions.length === 1) {
          return {
            row: possiblePositions[0].row,
            col: possiblePositions[0].col,
            value,
            reason: `The number ${value} can only be placed in this cell in this 3x3 box because all other positions in this box would create conflicts.`
          };
        }
      }
    }
  }
  
  // If no logical hint found, find an empty cell and provide the solution value
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (grid[row][col].value === null && !grid[row][col].isGiven) {
        return {
          row,
          col,
          value: solution[row][col],
          reason: `Based on the solution, this cell should contain ${solution[row][col]}.`
        };
      }
    }
  }
  
  return null; // No hint found (puzzle is complete)
};
