import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatTime(seconds: number, showSeconds: boolean = false): string {
  const minutes = Math.floor(seconds / 60);
  if (showSeconds) {
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
  return `${minutes} min`;
}

export function getBoxIndex(row: number, col: number, size: 4 | 9): number {
  if (size === 4) {
    return Math.floor(row / 2) * 2 + Math.floor(col / 2);
  } else {
    return Math.floor(row / 3) * 3 + Math.floor(col / 3);
  }
}

export function getBoxBounds(row: number, col: number, size: 4 | 9): { startRow: number; endRow: number; startCol: number; endCol: number } {
  if (size === 4) {
    const boxSize = 2;
    const startRow = Math.floor(row / boxSize) * boxSize;
    const startCol = Math.floor(col / boxSize) * boxSize;
    return {
      startRow,
      endRow: startRow + boxSize - 1,
      startCol,
      endCol: startCol + boxSize - 1
    };
  } else {
    const boxSize = 3;
    const startRow = Math.floor(row / boxSize) * boxSize;
    const startCol = Math.floor(col / boxSize) * boxSize;
    return {
      startRow,
      endRow: startRow + boxSize - 1,
      startCol,
      endCol: startCol + boxSize - 1
    };
  }
}

export function generateRandomPastelColor(): string {
  const hue = Math.floor(Math.random() * 360);
  const saturation = 70 + Math.random() * 10; // 70-80%
  const lightness = 80 + Math.random() * 10; // 80-90%
  return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
}

export function storageAvailable(type: 'localStorage' | 'sessionStorage'): boolean {
  let storage;
  try {
    storage = window[type];
    const x = '__storage_test__';
    storage.setItem(x, x);
    storage.removeItem(x);
    return true;
  } catch (e) {
    return false;
  }
}
