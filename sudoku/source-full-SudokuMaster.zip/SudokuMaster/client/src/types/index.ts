export type SudokuCell = {
  value: number | null;
  isGiven: boolean;
  notes: number[];
};

export type SudokuGrid = SudokuCell[][];

export type SelectedCell = {
  row: number;
  col: number;
} | null;

export type GridSize = 4 | 9;

export type Difficulty = 'easy' | 'medium' | 'hard';

export type HighlightSettings = {
  highlightRowColumn: boolean;
  highlightBox: boolean;
  highlightSameNumbers: boolean;
};

export type GameSettings = {
  gridSize: GridSize;
  difficulty: Difficulty;
  highlightSettings: HighlightSettings;
};

export type GameState = {
  grid: SudokuGrid;
  selectedCell: SelectedCell;
  solution: number[][];
  startTime: number;
  elapsedTime: number;
  isComplete: boolean; // Set to true when puzzle is correctly solved
  isPaused: boolean;
  isFilled: boolean; // Set to true when all cells have values
  isIncorrect: boolean; // Set to true when grid is filled but solution is wrong
};
