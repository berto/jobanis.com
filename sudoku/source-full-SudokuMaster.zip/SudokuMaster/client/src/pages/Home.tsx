import React from 'react';
import GameBoard from '@/components/GameBoard';
import BackgroundCircles from '@/components/BackgroundCircles';

const Home: React.FC = () => {
  return (
    <div className="font-sans text-gray-800 min-h-screen relative">
      <BackgroundCircles />
      <div className="max-w-[95vw] sm:max-w-md mx-auto px-2 sm:px-4 py-4 sm:py-8 relative z-10">
        <GameBoard />
      </div>
    </div>
  );
};

export default Home;
