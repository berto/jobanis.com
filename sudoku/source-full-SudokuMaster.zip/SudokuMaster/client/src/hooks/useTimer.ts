import { useState, useEffect, useCallback } from 'react';
import { formatTime } from '../lib/utils';

interface UseTimerProps {
  initialElapsedTime?: number;
  autoStart?: boolean;
}

export function useTimer({ initialElapsedTime = 0, autoStart = true }: UseTimerProps = {}) {
  const [elapsedTime, setElapsedTime] = useState<number>(initialElapsedTime);
  const [isRunning, setIsRunning] = useState<boolean>(autoStart);
  const [startTime, setStartTime] = useState<number>(Date.now() - initialElapsedTime * 1000);

  const start = useCallback(() => {
    if (!isRunning) {
      setIsRunning(true);
      setStartTime(Date.now() - elapsedTime * 1000);
    }
  }, [isRunning, elapsedTime]);

  const pause = useCallback(() => {
    if (isRunning) {
      setIsRunning(false);
    }
  }, [isRunning]);

  const reset = useCallback((newElapsedTime = 0) => {
    setIsRunning(false);
    setElapsedTime(newElapsedTime);
    setStartTime(Date.now() - newElapsedTime * 1000);
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (isRunning) {
      interval = setInterval(() => {
        setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
      }, 1000);
    } else if (interval) {
      clearInterval(interval);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, startTime]);

  const formattedTime = formatTime(elapsedTime);

  return {
    elapsedTime,
    formattedTime,
    isRunning,
    start,
    pause,
    reset
  };
}
