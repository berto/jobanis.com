import { useState, useEffect } from 'react';
import { GameSettings, GridSize, Difficulty, HighlightSettings } from '../types';
import { storageAvailable } from '../lib/utils';

const DEFAULT_SETTINGS: GameSettings = {
  gridSize: 9, // Large (9x9) grid
  difficulty: 'easy', // Easy difficulty
  highlightSettings: {
    highlightRowColumn: true,
    highlightBox: true,
    highlightSameNumbers: true
  }
};

export function useGameSettings() {
  const [settings, setSettings] = useState<GameSettings>(() => {
    if (storageAvailable('localStorage')) {
      const savedSettings = localStorage.getItem('sudokuSettings');
      if (savedSettings) {
        try {
          return JSON.parse(savedSettings) as GameSettings;
        } catch (e) {
          console.error('Failed to parse saved settings', e);
        }
      }
    }
    return DEFAULT_SETTINGS;
  });

  useEffect(() => {
    if (storageAvailable('localStorage')) {
      localStorage.setItem('sudokuSettings', JSON.stringify(settings));
    }
  }, [settings]);

  const updateGridSize = (size: GridSize) => {
    setSettings(prev => ({ ...prev, gridSize: size }));
  };

  const updateDifficulty = (difficulty: Difficulty) => {
    setSettings(prev => ({ ...prev, difficulty }));
  };

  const updateHighlightSettings = (newSettings: Partial<HighlightSettings>) => {
    setSettings(prev => ({
      ...prev,
      highlightSettings: {
        ...prev.highlightSettings,
        ...newSettings
      }
    }));
  };

  const resetSettings = () => {
    setSettings(DEFAULT_SETTINGS);
  };

  return {
    settings,
    updateGridSize,
    updateDifficulty,
    updateHighlightSettings,
    resetSettings
  };
}
