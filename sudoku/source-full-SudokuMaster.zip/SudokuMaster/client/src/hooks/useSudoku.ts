import { useState, useEffect, useCallback } from 'react';
import { SudokuGrid, SelectedCell, GridSize, Difficulty, GameState } from '../types';
import { generateSudoku, isValidValue, isSudokuComplete, isGridFilled, findHint } from '../lib/sudoku';
import { storageAvailable } from '../lib/utils';

export function useSudoku(size: GridSize, difficulty: Difficulty) {
  const [gameState, setGameState] = useState<GameState>(() => {
    // Try to load saved game from localStorage
    if (storageAvailable('localStorage')) {
      const savedGame = localStorage.getItem('sudokuGameState');
      if (savedGame) {
        try {
          const parsedGame = JSON.parse(savedGame) as GameState;
          // If grid size matches current settings, use saved game
          if (parsedGame.grid.length === size) {
            return parsedGame;
          }
        } catch (e) {
          console.error('Failed to parse saved game', e);
        }
      }
    }
    
    // Otherwise generate a new game
    const { grid, solution } = generateSudoku(size, difficulty);
    return {
      grid,
      solution,
      selectedCell: null,
      startTime: Date.now(),
      elapsedTime: 0,
      isComplete: false,
      isPaused: false,
      isFilled: false,
      isIncorrect: false
    };
  });

  // Save game state to localStorage whenever it changes
  useEffect(() => {
    if (storageAvailable('localStorage') && !gameState.isComplete) {
      localStorage.setItem('sudokuGameState', JSON.stringify(gameState));
    }
  }, [gameState]);

  // Select a cell
  const selectCell = useCallback((row: number, col: number) => {
    if (gameState.isComplete || gameState.isPaused) return;
    
    setGameState(prev => {
      // Don't select given cells
      if (prev.grid[row][col].isGiven) return prev;
      
      return {
        ...prev,
        selectedCell: { row, col }
      };
    });
  }, [gameState.isComplete, gameState.isPaused]);

  // Input a number into the selected cell
  const inputNumber = useCallback((number: number) => {
    if (!gameState.selectedCell || gameState.isComplete || gameState.isPaused) return;
    
    const { row, col } = gameState.selectedCell;
    
    setGameState(prev => {
      // Don't modify given cells
      if (prev.grid[row][col].isGiven) return prev;
      
      // Create a new grid with the updated value
      const newGrid = [...prev.grid.map(r => [...r])];
      newGrid[row][col] = {
        ...newGrid[row][col],
        value: number
      };
      
      // Check if all cells are filled
      const isFilled = isGridFilled(newGrid);
      
      // Check if the solution is correct (only if filled)
      const isComplete = isFilled && isSudokuComplete(newGrid, size);
      
      // Check if solution is incorrect (filled but not complete)
      const isIncorrect = isFilled && !isComplete;
      
      // If complete, clear from localStorage
      if (isComplete && storageAvailable('localStorage')) {
        localStorage.removeItem('sudokuGameState');
        console.log('Puzzle completed!');
      }
      
      return {
        ...prev,
        grid: newGrid,
        isComplete,
        isFilled,
        isIncorrect
      };
    });
  }, [gameState.selectedCell, gameState.isComplete, gameState.isPaused, size]);

  // Erase the value in the selected cell
  const eraseCell = useCallback(() => {
    if (!gameState.selectedCell || gameState.isComplete || gameState.isPaused) return;
    
    const { row, col } = gameState.selectedCell;
    
    setGameState(prev => {
      // Don't modify given cells
      if (prev.grid[row][col].isGiven) return prev;
      
      // Create a new grid with the erased value
      const newGrid = [...prev.grid.map(r => [...r])];
      newGrid[row][col] = {
        ...newGrid[row][col],
        value: null
      };
      
      // Update filled and incorrect states
      const isFilled = isGridFilled(newGrid);
      const isIncorrect = isFilled && !isSudokuComplete(newGrid, size);
      
      return {
        ...prev,
        grid: newGrid,
        isFilled,
        isIncorrect,
        isComplete: false // Erasing a cell means we're no longer complete
      };
    });
  }, [gameState.selectedCell, gameState.isComplete, gameState.isPaused, size]);

  // Start a new game
  const newGame = useCallback((newSize?: GridSize, newDifficulty?: Difficulty) => {
    const gameSize = newSize || size;
    const gameDifficulty = newDifficulty || difficulty;
    
    const { grid, solution } = generateSudoku(gameSize, gameDifficulty);
    
    setGameState({
      grid,
      solution,
      selectedCell: null,
      startTime: Date.now(),
      elapsedTime: 0,
      isComplete: false,
      isPaused: false,
      isFilled: false,
      isIncorrect: false
    });
    
    // Clear saved game in localStorage
    if (storageAvailable('localStorage')) {
      localStorage.removeItem('sudokuGameState');
    }
  }, [size, difficulty]);

  // Check if a value is valid for the current selected cell
  const isValueValid = useCallback((value: number): boolean => {
    if (!gameState.selectedCell) return false;
    
    const { row, col } = gameState.selectedCell;
    return isValidValue(gameState.grid, row, col, value, size);
  }, [gameState.selectedCell, gameState.grid, size]);

  // Update elapsed time
  const updateElapsedTime = useCallback((time: number) => {
    setGameState(prev => ({
      ...prev,
      elapsedTime: time
    }));
  }, []);

  // Pause/resume game
  const togglePause = useCallback(() => {
    setGameState(prev => ({
      ...prev,
      isPaused: !prev.isPaused
    }));
  }, []);
  
  // Get a hint
  const getHint = useCallback(() => {
    if (gameState.isComplete || gameState.isPaused) return null;
    
    const hint = findHint(gameState.grid, gameState.solution, size);
    
    if (hint) {
      // Select the cell for the hint
      selectCell(hint.row, hint.col);
    }
    
    return hint;
  }, [gameState.grid, gameState.solution, gameState.isComplete, gameState.isPaused, size, selectCell]);

  // Apply hint - directly inputs the correct value
  const applyHint = useCallback(() => {
    if (gameState.isComplete || gameState.isPaused) return null;
    
    const hint = findHint(gameState.grid, gameState.solution, size);
    
    if (hint) {
      // Select the cell for the hint
      selectCell(hint.row, hint.col);
      
      // Input the value
      setTimeout(() => {
        inputNumber(hint.value);
      }, 300); // Small delay to make the selection visible before the number appears
      
      return hint;
    }
    
    return null;
  }, [gameState.grid, gameState.solution, gameState.isComplete, gameState.isPaused, size, selectCell, inputNumber]);

  return {
    grid: gameState.grid,
    selectedCell: gameState.selectedCell,
    isComplete: gameState.isComplete,
    isPaused: gameState.isPaused,
    isFilled: gameState.isFilled,
    isIncorrect: gameState.isIncorrect,
    elapsedTime: gameState.elapsedTime,
    selectCell,
    inputNumber,
    eraseCell,
    newGame,
    isValueValid,
    updateElapsedTime,
    togglePause,
    getHint,
    applyHint
  };
}
