#!/bin/bash

# Create a temporary directory
mkdir -p temp_download

# Copy the static files
cp -r static/* temp_download/

# Create the zip archive
if command -v zip &> /dev/null; then
    zip -r sudoku-standalone.zip temp_download/*
else
    echo "Zip command not found. Please install zip or manually download the files from the static directory."
fi

# Clean up
rm -rf temp_download

echo "Download complete. The standalone Sudoku game is in sudoku-standalone.zip"